import Juego.Controlador.Juego;

public class Main {
    public static void main(String[] args) {
        while(Juego.menuLoop());
    }
}