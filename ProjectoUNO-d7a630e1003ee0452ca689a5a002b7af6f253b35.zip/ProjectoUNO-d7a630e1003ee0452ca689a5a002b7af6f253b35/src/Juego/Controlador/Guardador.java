package Juego.Controlador;

public class Guardador {
    private Guardador() {}

    public void guardarJuego() {
        // Guardamos la pila a tomar EN ORDEN
        // Guardamos la pila de juego EN ORDEN
        // Guardamos los jugadores como
        // "1": {
        //     "mazo": "R4 R5 B2 B1 CT4"
        //}
    }
}
