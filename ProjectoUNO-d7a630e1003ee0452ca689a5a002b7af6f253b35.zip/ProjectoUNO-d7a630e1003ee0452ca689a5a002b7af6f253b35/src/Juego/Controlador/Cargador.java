package Juego.Controlador;

public class Cargador {
    private Cargador() { }
}
