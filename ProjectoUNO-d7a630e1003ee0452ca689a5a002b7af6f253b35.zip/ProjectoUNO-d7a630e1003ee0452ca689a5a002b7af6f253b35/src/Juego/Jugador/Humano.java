package Juego.Jugador;

public class Humano extends Jugador {
}
