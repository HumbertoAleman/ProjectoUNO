package Juego.Jugador;

public class Computador extends Jugador {
}
