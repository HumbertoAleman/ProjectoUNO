package Juego.Jugador;

import Juego.Carta.Carta;

import java.util.LinkedList;

public abstract class Jugador {
        public LinkedList<Carta> mazo = new LinkedList<Carta>();
        public void agregarCarta(Carta carta) {
                mazo.add(carta);
        }

        public LinkedList<Carta> getMazo() {
                return mazo;
        }

}
