package Juego.Carta.Pila;

import Juego.Carta.Carta;

import java.util.List;
import java.util.Stack;

public class PilaJugar {
    private Stack<Carta> listaCartas = new Stack<Carta>();

    public boolean validarCarta(Carta carta) {
        return true;
    }

    public void jugarCarta(Carta carta) {

    }
}
